namespace Juegoflappy
{
    public partial class Form1 : Form
    {
        int ContadorMovimientos = 1;
        bool VolarArriba = false;
        int Distancia = 0;
        Random PosicionRandom = new Random();
        public Form1()
        {
            InitializeComponent();
            this.KeyPreview = true;
            IniciarJuego();
        }

        public void IniciarJuego()
        {
            player.Location = new Point(19, 225);
            Distancia = PosicionRandom.Next(-160, 118);
            TuboArriba.Location = new Point(270, -173 - Distancia);
            TuboAbajo.Location = new Point(270, 319 - Distancia);
            Puntaje.Text = "0";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int CantidadMovimientos = 5;
            if (ContadorMovimientos <= CantidadMovimientos)
            {
                player.Image = Properties.Resources.pajaro2;
                ContadorMovimientos++;
            }
            if ((ContadorMovimientos > CantidadMovimientos / 2) && (ContadorMovimientos <= CantidadMovimientos * 2))
            {
                player.Image = Properties.Resources.pajaro1;
                ContadorMovimientos++;
            }

            ContadorMovimientos = (ContadorMovimientos > CantidadMovimientos * 2) ? 0 : ContadorMovimientos;

            int ly = player.Location.Y;
            int lx = player.Location.X;

            if (VolarArriba)
            {
                ly = ly - 15;
                VolarArriba = false;
            }
            else
            {
                ly++;
            }

            player.Location = new Point(player.Location.X, ly);

            if ((player.Bounds.IntersectsWith(Barrera.Bounds)) || (player.Bounds.IntersectsWith(TuboArriba.Bounds)) || (player.Bounds.IntersectsWith(TuboAbajo.Bounds)))
            {
                IniciarJuego();
            }

            Puntaje.Location = new Point(player.Location.X + 30, player.Location.Y - 25);
            Puntaje.Text = (TuboArriba.Location.X == player.Location.X) ? Convert.ToString((Convert.ToInt32(Puntaje.Text) + 1)).ToString() : Puntaje.Text;
        }

        private void Form1_Keypress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Space))
            {
                VolarArriba = true;
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (TuboAbajo.Location.X > -140)
            {
                TuboAbajo.Location = new Point((TuboAbajo.Location.X) - 1, TuboAbajo.Location.Y);
                TuboArriba.Location = new Point((TuboArriba.Location.X) - 1, TuboArriba.Location.Y);
            }
            else
            {
                Distancia = PosicionRandom.Next(-170, 118);
                TuboAbajo.Location = new Point(400, 319 + Distancia);
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            Barrera.Location = (Barrera.Location.X > -480) ? new Point((Barrera.Location.X) - 1, Barrera.Location.Y) : Barrera.Location = new Point(-9, Barrera.Location.Y); 
        }
    }
}
