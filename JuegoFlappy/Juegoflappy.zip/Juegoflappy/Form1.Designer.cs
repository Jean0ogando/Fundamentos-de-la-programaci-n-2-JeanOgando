﻿namespace Juegoflappy
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            TuboArriba = new PictureBox();
            player = new PictureBox();
            TuboAbajo = new PictureBox();
            Barrera = new PictureBox();
            timer1 = new System.Windows.Forms.Timer(components);
            timer2 = new System.Windows.Forms.Timer(components);
            timer3 = new System.Windows.Forms.Timer(components);
            Puntaje = new Label();
            ((System.ComponentModel.ISupportInitialize)TuboArriba).BeginInit();
            ((System.ComponentModel.ISupportInitialize)player).BeginInit();
            ((System.ComponentModel.ISupportInitialize)TuboAbajo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Barrera).BeginInit();
            SuspendLayout();
            // 
            // TuboArriba
            // 
            TuboArriba.BackColor = Color.Transparent;
            TuboArriba.Image = Properties.Resources.Tuboarriba;
            TuboArriba.Location = new Point(134, -173);
            TuboArriba.Name = "TuboArriba";
            TuboArriba.Size = new Size(139, 371);
            TuboArriba.SizeMode = PictureBoxSizeMode.AutoSize;
            TuboArriba.TabIndex = 0;
            TuboArriba.TabStop = false;
            // 
            // player
            // 
            player.BackColor = Color.Transparent;
            player.Image = Properties.Resources.pajaro1;
            player.Location = new Point(19, 225);
            player.Name = "player";
            player.Size = new Size(83, 55);
            player.SizeMode = PictureBoxSizeMode.StretchImage;
            player.TabIndex = 1;
            player.TabStop = false;
            // 
            // TuboAbajo
            // 
            TuboAbajo.BackColor = Color.Transparent;
            TuboAbajo.Image = Properties.Resources.Tuboabajo;
            TuboAbajo.Location = new Point(134, 319);
            TuboAbajo.Name = "TuboAbajo";
            TuboAbajo.Size = new Size(139, 371);
            TuboAbajo.SizeMode = PictureBoxSizeMode.AutoSize;
            TuboAbajo.TabIndex = 2;
            TuboAbajo.TabStop = false;
            // 
            // Barrera
            // 
            Barrera.Image = Properties.Resources.Barra;
            Barrera.Location = new Point(-258, 432);
            Barrera.Name = "Barrera";
            Barrera.Size = new Size(779, 24);
            Barrera.SizeMode = PictureBoxSizeMode.StretchImage;
            Barrera.TabIndex = 3;
            Barrera.TabStop = false;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 10;
            timer1.Tick += timer1_Tick;
            // 
            // timer2
            // 
            timer2.Enabled = true;
            timer2.Interval = 1;
            timer2.Tick += timer2_Tick;
            // 
            // timer3
            // 
            timer3.Enabled = true;
            timer3.Interval = 5;
            timer3.Tick += timer3_Tick;
            // 
            // Puntaje
            // 
            Puntaje.AutoSize = true;
            Puntaje.BackColor = Color.Transparent;
            Puntaje.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Puntaje.Location = new Point(52, 198);
            Puntaje.Name = "Puntaje";
            Puntaje.Size = new Size(20, 23);
            Puntaje.TabIndex = 4;
            Puntaje.Text = "0";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.Fondo_flappy;
            ClientSize = new Size(290, 456);
            Controls.Add(Puntaje);
            Controls.Add(Barrera);
            Controls.Add(TuboAbajo);
            Controls.Add(player);
            Controls.Add(TuboArriba);
            Name = "Form1";
            Text = "Flappy bird";
            ((System.ComponentModel.ISupportInitialize)TuboArriba).EndInit();
            ((System.ComponentModel.ISupportInitialize)player).EndInit();
            ((System.ComponentModel.ISupportInitialize)TuboAbajo).EndInit();
            ((System.ComponentModel.ISupportInitialize)Barrera).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox TuboArriba;
        private PictureBox player;
        private PictureBox TuboAbajo;
        private PictureBox Barrera;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private Label Puntaje;
    }
}
