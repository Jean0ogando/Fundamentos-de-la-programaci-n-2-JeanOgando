﻿namespace DatagidviewJeanOgando
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dtgvMosler = new DataGridView();
            Codigo = new DataGridViewTextBoxColumn();
            Nombre = new DataGridViewTextBoxColumn();
            Precio = new DataGridViewTextBoxColumn();
            lblCodigo = new Label();
            txtcodigo = new TextBox();
            txtnombre = new TextBox();
            lblnombre = new Label();
            txtprecio = new TextBox();
            lblprecio = new Label();
            lblinformacion = new Label();
            btnadicionar = new Button();
            btnborrar = new Button();
            ((System.ComponentModel.ISupportInitialize)dtgvMosler).BeginInit();
            SuspendLayout();
            // 
            // dtgvMosler
            // 
            dtgvMosler.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvMosler.Columns.AddRange(new DataGridViewColumn[] { Codigo, Nombre, Precio });
            dtgvMosler.Location = new Point(12, 292);
            dtgvMosler.Name = "dtgvMosler";
            dtgvMosler.RowHeadersWidth = 51;
            dtgvMosler.Size = new Size(489, 197);
            dtgvMosler.TabIndex = 0;
            dtgvMosler.CellClick += dtgvMosler_CellClick;
            // 
            // Codigo
            // 
            Codigo.HeaderText = "Codigo Producto";
            Codigo.MinimumWidth = 6;
            Codigo.Name = "Codigo";
            Codigo.Width = 125;
            // 
            // Nombre
            // 
            Nombre.HeaderText = "Nombre Producto";
            Nombre.MinimumWidth = 6;
            Nombre.Name = "Nombre";
            Nombre.Width = 125;
            // 
            // Precio
            // 
            Precio.HeaderText = "Precio Producto";
            Precio.MinimumWidth = 6;
            Precio.Name = "Precio";
            Precio.Width = 125;
            // 
            // lblCodigo
            // 
            lblCodigo.AutoSize = true;
            lblCodigo.Location = new Point(12, 27);
            lblCodigo.Name = "lblCodigo";
            lblCodigo.Size = new Size(58, 20);
            lblCodigo.TabIndex = 1;
            lblCodigo.Text = "Codigo";
            // 
            // txtcodigo
            // 
            txtcodigo.Location = new Point(87, 27);
            txtcodigo.Name = "txtcodigo";
            txtcodigo.Size = new Size(125, 27);
            txtcodigo.TabIndex = 2;
            // 
            // txtnombre
            // 
            txtnombre.Location = new Point(87, 75);
            txtnombre.Name = "txtnombre";
            txtnombre.Size = new Size(125, 27);
            txtnombre.TabIndex = 4;
            // 
            // lblnombre
            // 
            lblnombre.AutoSize = true;
            lblnombre.Location = new Point(12, 75);
            lblnombre.Name = "lblnombre";
            lblnombre.Size = new Size(64, 20);
            lblnombre.TabIndex = 3;
            lblnombre.Text = "Nombre";
            // 
            // txtprecio
            // 
            txtprecio.Location = new Point(87, 126);
            txtprecio.Name = "txtprecio";
            txtprecio.Size = new Size(125, 27);
            txtprecio.TabIndex = 6;
            // 
            // lblprecio
            // 
            lblprecio.AutoSize = true;
            lblprecio.Location = new Point(12, 126);
            lblprecio.Name = "lblprecio";
            lblprecio.Size = new Size(50, 20);
            lblprecio.TabIndex = 5;
            lblprecio.Text = "Precio";
            // 
            // lblinformacion
            // 
            lblinformacion.AutoSize = true;
            lblinformacion.Location = new Point(20, 209);
            lblinformacion.Name = "lblinformacion";
            lblinformacion.Size = new Size(50, 20);
            lblinformacion.TabIndex = 7;
            lblinformacion.Text = "label1";
            // 
            // btnadicionar
            // 
            btnadicionar.Location = new Point(248, 27);
            btnadicionar.Name = "btnadicionar";
            btnadicionar.Size = new Size(94, 29);
            btnadicionar.TabIndex = 8;
            btnadicionar.Text = "Adicionar";
            btnadicionar.UseVisualStyleBackColor = true;
            btnadicionar.Click += btnadicionar_Click;
            // 
            // btnborrar
            // 
            btnborrar.Location = new Point(248, 73);
            btnborrar.Name = "btnborrar";
            btnborrar.Size = new Size(94, 29);
            btnborrar.TabIndex = 9;
            btnborrar.Text = "Borrar";
            btnborrar.UseVisualStyleBackColor = true;
            btnborrar.Click += btnborrar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(513, 508);
            Controls.Add(btnborrar);
            Controls.Add(btnadicionar);
            Controls.Add(lblinformacion);
            Controls.Add(txtprecio);
            Controls.Add(lblprecio);
            Controls.Add(txtnombre);
            Controls.Add(lblnombre);
            Controls.Add(txtcodigo);
            Controls.Add(lblCodigo);
            Controls.Add(dtgvMosler);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dtgvMosler).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dtgvMosler;
        private DataGridViewTextBoxColumn Codigo;
        private DataGridViewTextBoxColumn Nombre;
        private DataGridViewTextBoxColumn Precio;
        private Label lblCodigo;
        private TextBox txtcodigo;
        private TextBox txtnombre;
        private Label lblnombre;
        private TextBox txtprecio;
        private Label lblprecio;
        private Label lblinformacion;
        private Button btnadicionar;
        private Button btnborrar;
    }
}
