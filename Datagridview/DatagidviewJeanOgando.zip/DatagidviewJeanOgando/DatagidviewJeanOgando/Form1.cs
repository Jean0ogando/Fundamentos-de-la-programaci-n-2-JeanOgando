namespace DatagidviewJeanOgando
{
    public partial class Form1 : Form
    {

        private int n = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnadicionar_Click(object sender, EventArgs e)
        {
            //Adicionar nuevo rengl�n
            int n = dtgvMosler.Rows.Add();

            // Colocamos la informaci�n
            dtgvMosler.Rows[n].Cells[0].Value = txtcodigo.Text;
            dtgvMosler.Rows[n].Cells[1].Value = txtnombre.Text;
            dtgvMosler.Rows[n].Cells[2].Value = txtprecio.Text;

            // Limpiar los txt
            txtcodigo.Text = "";
            txtnombre.Text = "";
            txtprecio.Text = "";
        }

        private void dtgvMosler_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            n = e.RowIndex;

            if (n != -1)
            {
                lblinformacion.Text = (string)dtgvMosler.Rows[n].Cells[1].Value;
            }
        }

        private void btnborrar_Click(object sender, EventArgs e)
        {
            if(n!=-1)
            {
                dtgvMosler.Rows.RemoveAt(n);
            }
        }
    }
}