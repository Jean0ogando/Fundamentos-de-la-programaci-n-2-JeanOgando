﻿namespace DatagidviewJeanOgando
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dtgvMosler = new DataGridView();
            Codigo = new DataGridViewTextBoxColumn();
            Nombre = new DataGridViewTextBoxColumn();
            Precio = new DataGridViewTextBoxColumn();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            lblCodigo = new Label();
            txtcodigo = new TextBox();
            txtnombre = new TextBox();
            lblnombre = new Label();
            txtprecio = new TextBox();
            lblprecio = new Label();
            lblinformacion = new Label();
            btnadicionar = new Button();
            btnborrar = new Button();
            txtDaño = new TextBox();
            lblDaño = new Label();
            txtRiesgo = new TextBox();
            lblRiesgo = new Label();
            btnFase2 = new Button();
            ((System.ComponentModel.ISupportInitialize)dtgvMosler).BeginInit();
            SuspendLayout();
            // 
            // dtgvMosler
            // 
            dtgvMosler.AllowUserToDeleteRows = false;
            dtgvMosler.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvMosler.Columns.AddRange(new DataGridViewColumn[] { Codigo, Nombre, Precio, Column1, Column2 });
            dtgvMosler.Location = new Point(12, 292);
            dtgvMosler.Name = "dtgvMosler";
            dtgvMosler.ReadOnly = true;
            dtgvMosler.RowHeadersWidth = 51;
            dtgvMosler.Size = new Size(671, 197);
            dtgvMosler.TabIndex = 0;
            dtgvMosler.CellClick += dtgvMosler_CellClick;
            // 
            // Codigo
            // 
            Codigo.HeaderText = "ID";
            Codigo.MinimumWidth = 6;
            Codigo.Name = "Codigo";
            Codigo.ReadOnly = true;
            Codigo.Width = 125;
            // 
            // Nombre
            // 
            Nombre.HeaderText = "Nombre Completo";
            Nombre.MinimumWidth = 6;
            Nombre.Name = "Nombre";
            Nombre.ReadOnly = true;
            Nombre.Width = 125;
            // 
            // Precio
            // 
            Precio.HeaderText = "Activo";
            Precio.MinimumWidth = 6;
            Precio.Name = "Precio";
            Precio.ReadOnly = true;
            Precio.Width = 125;
            // 
            // Column1
            // 
            Column1.HeaderText = "Riesgo";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            Column1.Width = 125;
            // 
            // Column2
            // 
            Column2.HeaderText = "Daño";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            Column2.Width = 125;
            // 
            // lblCodigo
            // 
            lblCodigo.AutoSize = true;
            lblCodigo.Location = new Point(12, 27);
            lblCodigo.Name = "lblCodigo";
            lblCodigo.Size = new Size(58, 20);
            lblCodigo.TabIndex = 1;
            lblCodigo.Text = "Codigo";
            lblCodigo.Click += lblCodigo_Click;
            // 
            // txtcodigo
            // 
            txtcodigo.Location = new Point(87, 27);
            txtcodigo.Name = "txtcodigo";
            txtcodigo.Size = new Size(125, 27);
            txtcodigo.TabIndex = 2;
            // 
            // txtnombre
            // 
            txtnombre.Location = new Point(87, 75);
            txtnombre.Name = "txtnombre";
            txtnombre.Size = new Size(125, 27);
            txtnombre.TabIndex = 4;
            // 
            // lblnombre
            // 
            lblnombre.AutoSize = true;
            lblnombre.Location = new Point(12, 75);
            lblnombre.Name = "lblnombre";
            lblnombre.Size = new Size(64, 20);
            lblnombre.TabIndex = 3;
            lblnombre.Text = "Nombre";
            // 
            // txtprecio
            // 
            txtprecio.Location = new Point(87, 126);
            txtprecio.Name = "txtprecio";
            txtprecio.Size = new Size(125, 27);
            txtprecio.TabIndex = 6;
            // 
            // lblprecio
            // 
            lblprecio.AutoSize = true;
            lblprecio.Location = new Point(12, 126);
            lblprecio.Name = "lblprecio";
            lblprecio.Size = new Size(51, 20);
            lblprecio.TabIndex = 5;
            lblprecio.Text = "Activo";
            // 
            // lblinformacion
            // 
            lblinformacion.AutoSize = true;
            lblinformacion.Location = new Point(20, 209);
            lblinformacion.Name = "lblinformacion";
            lblinformacion.Size = new Size(89, 20);
            lblinformacion.TabIndex = 7;
            lblinformacion.Text = "Información";
            lblinformacion.Click += lblinformacion_Click;
            // 
            // btnadicionar
            // 
            btnadicionar.Location = new Point(553, 27);
            btnadicionar.Name = "btnadicionar";
            btnadicionar.Size = new Size(94, 29);
            btnadicionar.TabIndex = 8;
            btnadicionar.Text = "Adicionar";
            btnadicionar.UseVisualStyleBackColor = true;
            btnadicionar.Click += btnadicionar_Click;
            // 
            // btnborrar
            // 
            btnborrar.Location = new Point(553, 73);
            btnborrar.Name = "btnborrar";
            btnborrar.Size = new Size(94, 29);
            btnborrar.TabIndex = 9;
            btnborrar.Text = "Borrar";
            btnborrar.UseVisualStyleBackColor = true;
            btnborrar.Click += btnborrar_Click;
            // 
            // txtDaño
            // 
            txtDaño.Location = new Point(324, 77);
            txtDaño.Name = "txtDaño";
            txtDaño.Size = new Size(125, 27);
            txtDaño.TabIndex = 13;
            // 
            // lblDaño
            // 
            lblDaño.AutoSize = true;
            lblDaño.Location = new Point(249, 77);
            lblDaño.Name = "lblDaño";
            lblDaño.Size = new Size(45, 20);
            lblDaño.TabIndex = 12;
            lblDaño.Text = "Daño";
            // 
            // txtRiesgo
            // 
            txtRiesgo.Location = new Point(324, 29);
            txtRiesgo.Name = "txtRiesgo";
            txtRiesgo.Size = new Size(125, 27);
            txtRiesgo.TabIndex = 11;
            // 
            // lblRiesgo
            // 
            lblRiesgo.AutoSize = true;
            lblRiesgo.Location = new Point(249, 29);
            lblRiesgo.Name = "lblRiesgo";
            lblRiesgo.Size = new Size(54, 20);
            lblRiesgo.TabIndex = 10;
            lblRiesgo.Text = "Riesgo";
            // 
            // btnFase2
            // 
            btnFase2.Location = new Point(553, 126);
            btnFase2.Name = "btnFase2";
            btnFase2.Size = new Size(94, 29);
            btnFase2.TabIndex = 14;
            btnFase2.Text = "Fase 2";
            btnFase2.UseVisualStyleBackColor = true;
            btnFase2.Click += btnFase2_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Aquamarine;
            ClientSize = new Size(702, 508);
            Controls.Add(btnFase2);
            Controls.Add(txtDaño);
            Controls.Add(lblDaño);
            Controls.Add(txtRiesgo);
            Controls.Add(lblRiesgo);
            Controls.Add(btnborrar);
            Controls.Add(btnadicionar);
            Controls.Add(lblinformacion);
            Controls.Add(txtprecio);
            Controls.Add(lblprecio);
            Controls.Add(txtnombre);
            Controls.Add(lblnombre);
            Controls.Add(txtcodigo);
            Controls.Add(lblCodigo);
            Controls.Add(dtgvMosler);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dtgvMosler).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dtgvMosler;
        private Label lblCodigo;
        private TextBox txtcodigo;
        private TextBox txtnombre;
        private Label lblnombre;
        private TextBox txtprecio;
        private Label lblprecio;
        private Label lblinformacion;
        private Button btnadicionar;
        private Button btnborrar;
        private DataGridViewTextBoxColumn Codigo;
        private DataGridViewTextBoxColumn Nombre;
        private DataGridViewTextBoxColumn Precio;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private TextBox txtDaño;
        private Label lblDaño;
        private TextBox txtRiesgo;
        private Label lblRiesgo;
        private Button btnFase2;
    }
}
