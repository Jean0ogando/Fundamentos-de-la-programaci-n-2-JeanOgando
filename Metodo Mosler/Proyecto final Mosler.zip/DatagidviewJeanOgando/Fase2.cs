﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatagidviewJeanOgando
{
    public partial class Fase2 : Form
    {
        private int n = 0;
        public Fase2()
        {
            InitializeComponent();
        }

        private void btnadicionar_Click(object sender, EventArgs e)
        {
            //Adicionar nuevo renglón
            int n = dataFase2.Rows.Add();

            // Colocamos la información
            dataFase2.Rows[n].Cells[0].Value = txtFuncion.Text;
            dataFase2.Rows[n].Cells[1].Value = txtAgresión.Text;
            dataFase2.Rows[n].Cells[2].Value = txtSustitución.Text;
            dataFase2.Rows[n].Cells[3].Value = txtVulnerabilidad.Text;
            dataFase2.Rows[n].Cells[4].Value = txtProfundidad.Text;
            dataFase2.Rows[n].Cells[5].Value = txtExtensión.Text;

            // Limpiar los txt
            txtFuncion.Text = "";
            txtAgresión.Text = "";
            txtSustitución.Text = "";
            txtVulnerabilidad.Text = "";
            txtProfundidad.Text = "";
            txtExtensión.Text = "";
        }

        private void dtgvMosler_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            n = e.RowIndex;

            if (n != -1)
            {
                lblinformacion.Text = (string)dataFase2.Rows[n].Cells[1].Value;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 Volver = new Form1();
            Volver.Show();
            this.Close();
        }
    }
}
