﻿namespace DatagidviewJeanOgando
{
    partial class Fase2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataFase2 = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            button1 = new Button();
            button2 = new Button();
            txtProfundidad = new TextBox();
            lblProfundidad = new Label();
            txtVulnerabilidad = new TextBox();
            lblVulnerabilidad = new Label();
            lblinformacion = new Label();
            txtSustitución = new TextBox();
            lblsusticion = new Label();
            txtAgresión = new TextBox();
            lblAgresión = new Label();
            txtFuncion = new TextBox();
            lblFunción = new Label();
            txtExtensión = new TextBox();
            lblExtensión = new Label();
            btnadicionar = new Button();
            ((System.ComponentModel.ISupportInitialize)dataFase2).BeginInit();
            SuspendLayout();
            // 
            // dataFase2
            // 
            dataFase2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataFase2.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5, Column6 });
            dataFase2.Dock = DockStyle.Bottom;
            dataFase2.Location = new Point(0, 316);
            dataFase2.Name = "dataFase2";
            dataFase2.RowHeadersWidth = 51;
            dataFase2.Size = new Size(791, 224);
            dataFase2.TabIndex = 0;
            // 
            // Column1
            // 
            Column1.HeaderText = "Criterio Función";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.Width = 125;
            // 
            // Column2
            // 
            Column2.HeaderText = "Criterio Agresión";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.Width = 125;
            // 
            // Column3
            // 
            Column3.HeaderText = "Criterio Sustitución";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.Width = 125;
            // 
            // Column4
            // 
            Column4.HeaderText = "Criterio Vulnerabilidad";
            Column4.MinimumWidth = 6;
            Column4.Name = "Column4";
            Column4.Width = 125;
            // 
            // Column5
            // 
            Column5.HeaderText = "Criterio Profundidad";
            Column5.MinimumWidth = 6;
            Column5.Name = "Column5";
            Column5.Width = 125;
            // 
            // Column6
            // 
            Column6.HeaderText = "Criterio Extensión";
            Column6.MinimumWidth = 6;
            Column6.Name = "Column6";
            Column6.Width = 125;
            // 
            // button1
            // 
            button1.Location = new Point(653, 151);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 1;
            button1.Text = "Fase 1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(653, 203);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 2;
            button2.Text = "Fase 3";
            button2.UseVisualStyleBackColor = true;
            // 
            // txtProfundidad
            // 
            txtProfundidad.Location = new Point(383, 81);
            txtProfundidad.Name = "txtProfundidad";
            txtProfundidad.Size = new Size(125, 27);
            txtProfundidad.TabIndex = 24;
            // 
            // lblProfundidad
            // 
            lblProfundidad.AutoSize = true;
            lblProfundidad.Location = new Point(271, 81);
            lblProfundidad.Name = "lblProfundidad";
            lblProfundidad.Size = new Size(91, 20);
            lblProfundidad.TabIndex = 23;
            lblProfundidad.Text = "Profundidad";
            // 
            // txtVulnerabilidad
            // 
            txtVulnerabilidad.Location = new Point(383, 33);
            txtVulnerabilidad.Name = "txtVulnerabilidad";
            txtVulnerabilidad.Size = new Size(125, 27);
            txtVulnerabilidad.TabIndex = 22;
            // 
            // lblVulnerabilidad
            // 
            lblVulnerabilidad.AutoSize = true;
            lblVulnerabilidad.Location = new Point(271, 33);
            lblVulnerabilidad.Name = "lblVulnerabilidad";
            lblVulnerabilidad.Size = new Size(106, 20);
            lblVulnerabilidad.TabIndex = 21;
            lblVulnerabilidad.Text = "Vulnerabilidad";
            // 
            // lblinformacion
            // 
            lblinformacion.AutoSize = true;
            lblinformacion.Location = new Point(42, 213);
            lblinformacion.Name = "lblinformacion";
            lblinformacion.Size = new Size(89, 20);
            lblinformacion.TabIndex = 20;
            lblinformacion.Text = "Información";
            // 
            // txtSustitución
            // 
            txtSustitución.Location = new Point(121, 130);
            txtSustitución.Name = "txtSustitución";
            txtSustitución.Size = new Size(125, 27);
            txtSustitución.TabIndex = 19;
            // 
            // lblsusticion
            // 
            lblsusticion.AutoSize = true;
            lblsusticion.Location = new Point(34, 130);
            lblsusticion.Name = "lblsusticion";
            lblsusticion.Size = new Size(81, 20);
            lblsusticion.TabIndex = 18;
            lblsusticion.Text = "Sustitución";
            // 
            // txtAgresión
            // 
            txtAgresión.Location = new Point(121, 79);
            txtAgresión.Name = "txtAgresión";
            txtAgresión.Size = new Size(125, 27);
            txtAgresión.TabIndex = 17;
            // 
            // lblAgresión
            // 
            lblAgresión.AutoSize = true;
            lblAgresión.Location = new Point(34, 79);
            lblAgresión.Name = "lblAgresión";
            lblAgresión.Size = new Size(68, 20);
            lblAgresión.TabIndex = 16;
            lblAgresión.Text = "Agresión";
            // 
            // txtFuncion
            // 
            txtFuncion.Location = new Point(121, 31);
            txtFuncion.Name = "txtFuncion";
            txtFuncion.Size = new Size(125, 27);
            txtFuncion.TabIndex = 15;
            // 
            // lblFunción
            // 
            lblFunción.AutoSize = true;
            lblFunción.Location = new Point(34, 31);
            lblFunción.Name = "lblFunción";
            lblFunción.Size = new Size(60, 20);
            lblFunción.TabIndex = 14;
            lblFunción.Text = "Función";
            // 
            // txtExtensión
            // 
            txtExtensión.Location = new Point(383, 130);
            txtExtensión.Name = "txtExtensión";
            txtExtensión.Size = new Size(125, 27);
            txtExtensión.TabIndex = 26;
            // 
            // lblExtensión
            // 
            lblExtensión.AutoSize = true;
            lblExtensión.Location = new Point(271, 130);
            lblExtensión.Name = "lblExtensión";
            lblExtensión.Size = new Size(72, 20);
            lblExtensión.TabIndex = 25;
            lblExtensión.Text = "Extensión";
            // 
            // btnadicionar
            // 
            btnadicionar.Location = new Point(653, 33);
            btnadicionar.Name = "btnadicionar";
            btnadicionar.Size = new Size(94, 29);
            btnadicionar.TabIndex = 27;
            btnadicionar.Text = "Adicionar";
            btnadicionar.UseVisualStyleBackColor = true;
            // 
            // Fase2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Aquamarine;
            ClientSize = new Size(791, 540);
            Controls.Add(btnadicionar);
            Controls.Add(txtExtensión);
            Controls.Add(lblExtensión);
            Controls.Add(txtProfundidad);
            Controls.Add(lblProfundidad);
            Controls.Add(txtVulnerabilidad);
            Controls.Add(lblVulnerabilidad);
            Controls.Add(lblinformacion);
            Controls.Add(txtSustitución);
            Controls.Add(lblsusticion);
            Controls.Add(txtAgresión);
            Controls.Add(lblAgresión);
            Controls.Add(txtFuncion);
            Controls.Add(lblFunción);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(dataFase2);
            Name = "Fase2";
            Text = "Fase2";
            ((System.ComponentModel.ISupportInitialize)dataFase2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataFase2;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private Button button1;
        private Button button2;
        private TextBox txtProfundidad;
        private Label lblProfundidad;
        private TextBox txtVulnerabilidad;
        private Label lblVulnerabilidad;
        private Label lblinformacion;
        private TextBox txtSustitución;
        private Label lblsusticion;
        private TextBox txtAgresión;
        private Label lblAgresión;
        private TextBox txtFuncion;
        private Label lblFunción;
        private TextBox txtExtensión;
        private Label lblExtensión;
        private Button btnadicionar;
    }
}