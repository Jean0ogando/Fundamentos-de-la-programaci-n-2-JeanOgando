namespace MenúWindows
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void acercaDeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ejemplo de Información");
        }

        private void sumarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            double a = Convert.ToDouble(txtA.Text);
            double b = Convert.ToDouble(TxtB.Text);

            double r = a + b;
            lblResultado.Text = r.ToString();
        }

        private void restarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            double a = Convert.ToDouble(txtA.Text);
            double b = Convert.ToDouble(TxtB.Text);

            double r = a - b;
            lblResultado.Text = r.ToString();
        }

        private void multiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            double a = Convert.ToDouble(txtA.Text);
            double b = Convert.ToDouble(TxtB.Text);

            double r = a * b;
            lblResultado.Text = r.ToString();
        }

        private void divisiónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            double a = Convert.ToDouble(txtA.Text);
            double b = Convert.ToDouble(TxtB.Text);

            double r = a / b;
            lblResultado.Text = r.ToString();
        }
    }
}
